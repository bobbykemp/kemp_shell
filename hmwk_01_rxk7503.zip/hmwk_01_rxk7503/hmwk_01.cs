// Kemp, Robert JT
// rxk7503
// 2018-08-24

using System;

public class hmwk_01
{
  static public void Main( string[] args )
  {
    Console.WriteLine("Hello, world!");
  }
}

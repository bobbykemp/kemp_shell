// Kemp, Robert JT
// rxk7503
// 2018-08-24

public class hmwk_01 {
  public static void main( String[] args )
  {
    System.out.println("Hello, world!");
  }
}
